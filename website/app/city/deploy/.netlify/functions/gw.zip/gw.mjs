
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/gw.mjs
import crypto from "node:crypto";
var ROUTES = [
  { method: "GET", match: /^\/v1\/city\/status$/, kind: "status" },
  { method: "GET", match: /^\/v1\/city\/world$/, kind: "world" }
];
var JSONH = { "content-type": "application/json", "cache-control": "no-store" };
var refuse = (status, msg) => new Response(JSON.stringify({ error: msg }), { status, headers: JSONH });
var text = (v, max) => typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max || 80) : null;
var num = (v) => typeof v === "number" && isFinite(v) ? v : null;
var agoMin = (iso, now) => {
  const t = Date.parse(typeof iso === "string" ? iso : "");
  return isFinite(t) ? Math.max(0, Math.round((now - t) / 6e4)) : null;
};
var eventId = (internal) => "ev_" + crypto.createHash("sha256").update("pauli-city:" + String(internal)).digest("hex").slice(0, 12);
function statusDTO(src, now) {
  const s = src && typeof src === "object" ? src : {};
  const health = !!(s.health && s.health.status === "online") && !s.degraded;
  const citizens = (Array.isArray(s.citizens) ? s.citizens : []).map((c) => c && typeof c === "object" ? {
    name: text(c.name, 40),
    role: text(c.role, 40),
    district: text(c.district, 40),
    status: c.status === "online" ? "online" : "offline",
    hero: c.id === "agent" || c.role === "orchestrator" || void 0
  } : null).filter((c) => c && c.name).map((c) => {
    if (!c.hero) delete c.hero;
    return c;
  });
  const activity = (Array.isArray(s.activeTasks) ? s.activeTasks : []).map((t) => t && typeof t === "object" && t.id != null ? {
    event: eventId(t.id),
    state: ["running", "completed", "failed", "accepted"].includes(t.status) ? t.status : "unknown",
    agent: t.context && typeof t.context.agentId === "string" ? text(((Array.isArray(s.citizens) ? s.citizens : []).find((c) => c && c.id === t.context.agentId) || {}).name, 40) || null : null,
    summary: text(t.task, 80),
    startedAgoMin: agoMin(t.startedAt, now),
    settledAgoMin: agoMin(t.completedAt, now),
    receipt: !!t.receiptId
  } : null).filter(Boolean);
  return {
    live: health,
    city: { name: text(s.city && s.city.name, 60) || "Pauli's Place" },
    generatedAgoMin: agoMin(s.generatedAt, now),
    citizens,
    activity
  };
}
function worldDTO(src, idToName) {
  const w = src && typeof src === "object" ? src : {};
  const st = w.station && typeof w.station === "object" ? w.station : {};
  if (!st.rooms || typeof st.rooms !== "object") return { ok: false, error: "no station" };
  const rooms = {};
  for (const [rid, r] of Object.entries(st.rooms)) {
    if (!r || typeof r !== "object") continue;
    rooms[rid] = {
      id: text(r.id, 40) || rid,
      kind: text(r.kind, 24),
      name: text(r.name, 40),
      rects: (Array.isArray(r.rects) ? r.rects : []).map((q) => q && typeof q === "object" ? { x1: num(q.x1), y1: num(q.y1), x2: num(q.x2), y2: num(q.y2) } : null).filter((q) => q && q.x1 != null && q.y1 != null && q.x2 != null && q.y2 != null),
      floorStyle: text(r.floorStyle, 24),
      wallStyle: text(r.wallStyle, 24),
      tier: num(r.tier) || 0,
      floorPaint: r.floorPaint && typeof r.floorPaint === "object" ? r.floorPaint : {}
    };
  }
  const props = (Array.isArray(st.props) ? st.props : []).map((p) => p && typeof p === "object" ? {
    id: text(p.id, 40),
    t: text(p.t, 40),
    x: num(p.x),
    y: num(p.y),
    w: num(p.w),
    h: num(p.h),
    block: p.block !== false,
    agentId: p.agentId ? idToName.get(String(p.agentId)) || null : void 0,
    brief: void 0
  } : null).filter((p) => p && p.id && p.t && p.x != null && p.y != null).map((p) => {
    if (p.agentId == null) delete p.agentId;
    delete p.brief;
    return p;
  });
  const belts = {};
  if (st.belts && typeof st.belts === "object") {
    for (const [k, v] of Object.entries(st.belts)) if (typeof v === "string" && v.length <= 4) belts[k] = v;
  }
  const edges = (Array.isArray(st.edges) ? st.edges : []).map((e) => e && typeof e === "object" ? {
    from: e.from ? idToName.get(String(e.from)) || null : null,
    to: e.to ? idToName.get(String(e.to)) || null : null,
    whenKind: text(e.whenKind, 24)
  } : null).filter((e) => e && e.from && e.to);
  return {
    ok: true,
    station: {
      schema: "starnet.station",
      version: num(st.version) || 1,
      meta: {
        name: text(st.meta && st.meta.name, 60) || "PAULI'S PLACE",
        tier: num(st.meta && st.meta.tier) || 0,
        spawnRoomId: rooms[st.meta && st.meta.spawnRoomId] ? st.meta.spawnRoomId : null,
        trunkRoomId: rooms[st.meta && st.meta.trunkRoomId] ? st.meta.trunkRoomId : null
      },
      rooms,
      order: (Array.isArray(st.order) ? st.order : []).filter((id) => typeof id === "string" && rooms[id]),
      props,
      belts,
      edges
    }
  };
}
var gw_default = async (req) => {
  const GW = (process.env.PAULI_GATEWAY_URL || "").replace(/\/+$/, "");
  const TOK = process.env.PAULI_GATEWAY_TOKEN || "";
  if (!GW || !TOK) return refuse(503, "gateway not configured");
  const url = new URL(req.url);
  const sub = url.pathname.replace(/^\/\.netlify\/functions\/gw/, "") || "/";
  const route = ROUTES.find((r) => r.method === req.method && r.match.test(sub));
  if (!route) return refuse(404, "not found");
  const get = async (path) => {
    const resp = await fetch(GW + path, { method: "GET", headers: { authorization: "Bearer " + TOK } });
    if (!resp.ok) throw Object.assign(new Error("upstream"), { status: resp.status });
    return resp.json();
  };
  try {
    if (route.kind === "status") {
      return new Response(JSON.stringify(statusDTO(await get("/v1/city/status"), Date.now())), { status: 200, headers: JSONH });
    }
    const [world, status] = await Promise.all([get("/v1/city/world"), get("/v1/city/status")]);
    const idToName = new Map((Array.isArray(status.citizens) ? status.citizens : []).filter((c) => c && c.id && c.name).map((c) => [String(c.id), String(c.name)]));
    const out = worldDTO(world, idToName);
    return new Response(JSON.stringify(out), { status: out.ok ? 200 : 503, headers: JSONH });
  } catch (e) {
    return refuse(e && e.status === 404 ? 404 : 502, "upstream refused");
  }
};
export {
  gw_default as default
};
