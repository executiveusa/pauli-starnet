
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/gw.mjs
var gw_default = async (req) => {
  const GW = (process.env.PAULI_GATEWAY_URL || "").replace(/\/+$/, "");
  const TOK = process.env.PAULI_GATEWAY_TOKEN || "";
  if (!GW || !TOK) {
    return new Response(JSON.stringify({ error: "gateway not configured" }), {
      status: 503,
      headers: { "content-type": "application/json" }
    });
  }
  const url = new URL(req.url);
  const sub = url.pathname.replace(/^\/\.netlify\/functions\/gw/, "") || "/";
  const headers = { authorization: "Bearer " + TOK };
  let body;
  if (req.method !== "GET" && req.method !== "HEAD") {
    headers["content-type"] = req.headers.get("content-type") || "application/json";
    body = await req.text();
  }
  try {
    const resp = await fetch(GW + sub + url.search, { method: req.method, headers, body });
    const text = await resp.text();
    return new Response(text, {
      status: resp.status,
      headers: { "content-type": resp.headers.get("content-type") || "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: "gateway unreachable" }), {
      status: 502,
      headers: { "content-type": "application/json" }
    });
  }
};
export {
  gw_default as default
};
